description      "Installs and configures application"
version          "0.1.0"

depends "nginx"
