Description
===========

Installs and configures the "application"


Requirements
============

* Nginx

