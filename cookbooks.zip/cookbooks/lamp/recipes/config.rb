node.default['mariadb']['root']['password'] = 'admin'
node.default['mariadb']['database']['name'] = 'codeigniter'
node.default['mariadb']['database']['user'] = 'webuser'
node.default['mariadb']['database']['password'] = 'admin123'