include_recipe "lamp::config"
remote_file '/tmp/codeingiter_source.zip' do
  source 'https://github.com/bcit-ci/CodeIgniter/archive/3.1.4.zip'
end
bash "unzip CodeIgniter" do
  code <<-EOT
  rm -rf /var/www/html/{*,.*}
  unzip /tmp/codeingiter_source.zip -d /var/www/html/
  mv /var/www/html/CodeIgniter-*/{*,.*} /var/www/html/
  chown -R vagrant:vagrant /var/www/html/
  rmdir /var/www/html/CodeIgniter-*
  EOT
end
template '/var/www/html/application/config/database.php' do
  source 'database.php.erb'
variables ({
  	:database_name		=> node['mariadb']['database']['name'],
  	:database_user		=> node['mariadb']['database']['user'],
  	:database_password	=> node['mariadb']['database']['password']
  })
end