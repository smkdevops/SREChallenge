name "prod"
description "production env"
cookbook "apache", "= 0.1.0"
